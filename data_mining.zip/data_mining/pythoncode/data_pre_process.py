import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.preprocessing import StandardScaler

# 1. 读取数据
data = pd.read_csv(r'C:\Users\xwj\Desktop\data_mining\csv\winequality-white.csv', delimiter=';')

# 2. 定义需要处理的列
features = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
            'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 
            'density', 'pH', 'sulphates', 'alcohol']

# 3. IQR 方法去除离群点
def remove_outliers_iqr(df, features, multiplier=1.5):
    Q1 = df[features].quantile(0.25)
    Q3 = df[features].quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - multiplier * IQR
    upper_bound = Q3 + multiplier * IQR

    outlier_mask = ((df[features] < lower_bound) | (df[features] > upper_bound)).any(axis=1)
    return df[~outlier_mask], df[outlier_mask]

# IQR 清理
multiplier = 4.0
clean_data_iqr, outliers_iqr = remove_outliers_iqr(data, features, multiplier=multiplier)

# 4. Z-score 方法去除离群点
def remove_outliers_zscore(df, features, threshold=3):
    z_scores = np.abs(zscore(df[features]))
    outlier_mask = (z_scores > threshold).any(axis=1)
    return df[~outlier_mask], df[outlier_mask]

# Z-score 清理
threshold = 4.0
clean_data_z, outliers_z = remove_outliers_zscore(clean_data_iqr, features, threshold=threshold)

# 5. 计算最终的离群点（IQR 和 Z-score 联合结果）
final_outliers = pd.concat([outliers_iqr, outliers_z]).drop_duplicates()
final_cleaned_data = clean_data_z  # Z-score 去除后的数据是最终的

# 6. 标准化数据
scaler = StandardScaler()
data_scaled = data.copy()
data_scaled[features] = scaler.fit_transform(data[features])

# 7. 绘制箱线图（去除离群点前后的对比）
def plot_boxplots_comparison(original_data, cleaned_data, features, save_dir):
    plt.figure(figsize=(16, 12))
    
    for i, feature in enumerate(features):
        plt.subplot(3, 4, i + 1)
        # 获取当前特征的最小值和最大值
        y_min = min(original_data[feature].min(), cleaned_data[feature].min())
        y_max = max(original_data[feature].max(), cleaned_data[feature].max())
        
        sns.boxplot(data=[original_data[feature], cleaned_data[feature]], palette="Set2")
        plt.xticks([0, 1], ['Original Data', 'Cleaned Data'])
        plt.title(f'Boxplot of {feature}')
        plt.ylim(y_min, y_max)  # 设置相同的纵坐标范围
        
    plt.tight_layout()
    # 保存箱线图
    plt.savefig(f'{save_dir}/boxplot_comparison.png')
    plt.show()

# 8. 保存去除离群点前后的箱线图（分别保存两张）
def plot_boxplots_individual(original_data, cleaned_data, features, save_dir):
    # 绘制去除离群点前的箱线图
    plt.figure(figsize=(16, 12))
    for i, feature in enumerate(features):
        plt.subplot(3, 4, i + 1)
        sns.boxplot(original_data[feature], palette="Set2")
        plt.title(f'Boxplot of {feature} (Original)')
        plt.tight_layout()
    plt.savefig(f'{save_dir}/boxplot_original.png')
    plt.show()

    # 绘制去除离群点后的箱线图
    plt.figure(figsize=(16, 12))
    for i, feature in enumerate(features):
        plt.subplot(3, 4, i + 1)
        sns.boxplot(cleaned_data[feature], palette="Set2")
        plt.title(f'Boxplot of {feature} (Cleaned)')
        plt.tight_layout()
    plt.savefig(f'{save_dir}/boxplot_cleaned.png')
    plt.show()

# 9. 绘制标准化前后数据的分布图
def plot_standardization_comparison(original_data, scaled_data, features, save_dir):
    plt.figure(figsize=(16, 12))
    
    for i, feature in enumerate(features):
        plt.subplot(3, 4, i + 1)
        
        # 绘制标准化前后的分布
        sns.histplot(original_data[feature], kde=True, color='blue', label='Original', stat='density', bins=20)
        sns.histplot(scaled_data[feature], kde=True, color='red', label='Scaled', stat='density', bins=20)
        
        plt.legend()
        #plt.title(f'Distribution of {feature} (Before & After Standardization)')
        plt.tight_layout()
    
    plt.savefig(f'{save_dir}/standardization_comparison.png')
    plt.show()

print("绘制标准化前后的分布图：")
plot_standardization_comparison(data, data_scaled, features, r'C:\Users\xwj\Desktop\data_mining\images')

print("分别保存去除离群点前后的箱线图：")
plot_boxplots_individual(data, final_cleaned_data, features, r'C:\Users\xwj\Desktop\data_mining\images')

# 10. 保存结果
final_cleaned_data.to_csv(r'C:\Users\xwj\Desktop\data_mining\csv\IQR_Z_cleaned.csv', index=False, sep=';')
final_outliers.to_csv(r'C:\Users\xwj\Desktop\data_mining\csv\IQR_Z_outliers.csv', index=False, sep=';')

# 11. 输出数据概况
print(f"原始数据量: {data.shape[0]}")
print(f"IQR 方法去除的数据量: {outliers_iqr.shape[0]}")
print(f"Z-score 方法去除的数据量: {outliers_z.shape[0]}")
print(f"最终离群点总数: {outliers_iqr.shape[0]+outliers_z.shape[0]}")
print(f"最终清理后的数据量: {final_cleaned_data.shape[0]}")
