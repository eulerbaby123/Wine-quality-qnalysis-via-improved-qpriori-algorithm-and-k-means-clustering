import pandas as pd

# 定义数据
data = {
    "Feature": [
        "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
        "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
        "pH", "sulphates", "alcohol"
    ],
    "K": [4, 3, 5, 3, 5, 3, 3, 3, 3, 3, 3],
    "Class Intervals": [
        "[-1.34, -0.33], [-0.33, 0.61], [0.61, 1.96], [1.96, 3.81]",
        "[-0.86, 0.26], [0.26, 1.95], [1.95, 4.22]",
        "[-1.68, -0.54], [-0.54, 0.26], [0.26, 1.40], [1.40, 3.13], [3.13, 4.02]",
        "[-0.86, 0.27], [0.27, 1.58], [1.58, 3.93]",
        "[-1.33, -0.44], [-0.44, 0.37], [0.37, 1.21], [1.21, 2.79], [2.79, 4.27]",
        "[-1.03, 0.07], [0.07, 1.39], [1.39, 3.97]",
        "[-1.00, 0.12], [0.12, 1.37], [1.37, 3.96]",
        "[-1.03, 0.11], [0.11, 1.37], [1.37, 3.07]",
        "[-1.08, 0.07], [0.07, 1.44], [1.44, 4.00]",
        "[-0.88, 0.27], [0.27, 1.85], [1.85, 4.11]",
        "[-0.93, 0.25], [0.25, 1.53], [1.53, 2.98]"
    ]
}

# 创建DataFrame
df = pd.DataFrame(data)

# 定义文件保存路径
output_path = r'C:\Users\xwj\Desktop\data_mining\csv\intervals.xlsx'

# 写入Excel文件
df.to_excel(output_path, index=False)

output_path
