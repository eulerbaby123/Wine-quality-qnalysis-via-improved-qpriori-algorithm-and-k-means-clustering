import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules

# 1. 读取离散化后的数据
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\final_quality_clustered.csv'
data = pd.read_csv(file_path, delimiter=';')

# 2. 数据转换为布尔类型（适合Apriori）
data_bool = pd.get_dummies(data.astype(str), prefix_sep='_')

# 3. 使用Apriori算法挖掘频繁项集
min_support = 0.1
frequent_itemsets = apriori(data_bool, min_support=min_support, use_colnames=True)

# 4. 生成关联规则 (兼容旧版本)
min_confidence = 0.95
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=min_confidence, num_itemsets=len(frequent_itemsets))

# 5. 筛选并展示结果
print("频繁项集：")
print(frequent_itemsets)

print("\n关联规则：")
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

# 6. 保存结果
frequent_itemsets.to_csv(r'C:\Users\xwj\Desktop\data_mining\csv\frequent_itemsets.csv', index=False, sep=';')
rules.to_csv(r'C:\Users\xwj\Desktop\data_mining\csv\association_rules.csv', index=False, sep=';')

print("\n结果已保存到以下文件：")
print("1. frequent_itemsets.csv - 频繁项集")
print("2. association_rules.csv - 关联规则")

