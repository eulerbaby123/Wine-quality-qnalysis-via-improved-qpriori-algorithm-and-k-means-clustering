import pandas as pd

# 读取CSV文件
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\final_quality_clustered.csv'
data = pd.read_csv(file_path, delimiter=';')

# 统计各quality的数量
quality_counts = data['quality'].value_counts()

# 打印统计结果
print("各quality的葡萄酒数量:")
print(quality_counts)

# 如果需要保存统计结果到文件
output_path = r'C:\Users\xwj\Desktop\data_mining\txtfile\quality_counts.txt'
with open(output_path, 'w',encoding='utf-8') as f:
    f.write("各quality的葡萄酒数量:\n")
    f.write(quality_counts.to_string())
