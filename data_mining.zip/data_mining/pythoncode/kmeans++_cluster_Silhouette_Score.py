import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

# 1. 读取数据
data = pd.read_csv(r'C:\Users\xwj\Desktop\data_mining\csv\IQR_Z_cleaned.csv', delimiter=';')

# 2. 定义需要处理的特征列
features = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
            'chlorides', 'free sulfur dioxide', 'total sulfur dioxide',
            'density', 'pH', 'sulphates', 'alcohol']

# 3. 针对单个特征进行标准化和聚类
def auto_select_k(data, feature, k_range=(3, 5)):
    print(f"\n正在处理特征: {feature}")
    scaler = StandardScaler()
    feature_scaled = scaler.fit_transform(data[[feature]])
    
    # 存储每个 K 值的轮廓系数
    silhouette_scores = []
    
    # 遍历不同 K 值，计算轮廓系数
    for k in range(k_range[0], k_range[1] + 1):
        kmeans = KMeans(n_clusters=k, init='k-means++', random_state=42)
        cluster_labels = kmeans.fit_predict(feature_scaled)
        score = silhouette_score(feature_scaled, cluster_labels)
        silhouette_scores.append(score)
    
    # 找到轮廓系数最大的 K 值
    best_k = k_range[0] + np.argmax(silhouette_scores)
    print(f"最佳 K 值为: {best_k}，轮廓系数为: {max(silhouette_scores):.3f}")
    
    # 使用最佳 K 值重新聚类
    kmeans = KMeans(n_clusters=best_k, init='k-means++', random_state=42)
    cluster_labels = kmeans.fit_predict(feature_scaled)
    
    # 返回聚类结果和类中心排序
    cluster_centers = np.sort(kmeans.cluster_centers_.flatten())
    return cluster_labels + 1, cluster_centers

# 4. 对所有特征进行处理
k_values = {}
final_discretized_data = pd.DataFrame()

for feature in features:
    # 计算最佳K值并聚类
    data[feature + '_cluster'], centers = auto_select_k(data, feature)
    
    # 计算区间
    print(f"特征 {feature} 的类区间:")
    intervals = []
    
    # 对非最后一个类，区间是从本类的最小值到下一个类的最小值
    for i in range(len(centers) - 1):
        lower = centers[i]
        upper = centers[i + 1]
        
        intervals.append((lower, upper))
        print(f"类 {i + 1}: 区间 [{lower:.2f}, {upper:.2f}]")
    # 对最后一个类，区间是从本类最小值到标准化数据的最大值
    scaler = StandardScaler()
    feature_scaled = scaler.fit_transform(data[[feature]])
    lower = centers[-1]
    upper = scaler.transform([[np.max(data[feature])]])[0, 0]  # 将最大值转换到标准化范围
    intervals.append((lower, upper))
    print(f"类 {len(centers)}: 区间 [{lower:.2f}, {upper:.2f}]")

    # # 对最后一个类，区间是从本类最小值到数据的最大值
    # lower = centers[-1]
    # upper = np.max(data[feature])
    # intervals.append((lower, upper))
    # print(f"类 {len(centers)}: 区间 [{lower:.2f}, {upper:.2f}]")

    # 保存区间信息
    k_values[feature] = {'K': len(centers), 'Intervals': intervals}

    # 将离散化数据保存到final_discretized_data
    final_discretized_data[feature + '_cluster'] = data[feature + '_cluster']

# 5. 加入 `quality` 特征到 `final_discretized_data`
final_discretized_data['quality'] = data['quality']

# 6. 保存处理后的离散化数据
output_path = r'C:\Users\xwj\Desktop\data_mining\csv\kmeans_discretized_auto.csv'
final_discretized_data.to_csv(output_path, index=False, sep=';')
print(f"\n已保存自动离散化后的数据至: {output_path}")

# 7. 保存区间信息
intervals_output_path = r'C:\Users\xwj\Desktop\data_mining\txtfile\intervals_elbow.txt'
with open(intervals_output_path, 'w',encoding='utf-8') as f:
    for feature, info in k_values.items():
        f.write(f"{feature} - K: {info['K']}\n")
        for idx, (low, high) in enumerate(info['Intervals']):
            f.write(f"  类 {idx + 1}: 区间 [{low:.2f}, {high:.2f}]\n")
        f.write("\n")

print(f"\n区间信息已保存至: {intervals_output_path}")

# 8. 显示结果示例
print(final_discretized_data.head())
