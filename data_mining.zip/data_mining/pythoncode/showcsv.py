import pandas as pd
import matplotlib.pyplot as plt
from pandas.plotting import table

# 加载数据集
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\winequality-white.csv'
df = pd.read_csv(file_path, delimiter=';')

# 获取前几行数据
top_rows = df.head()

# 创建一个新的图形
fig, ax = plt.subplots(figsize=(10, 4))  # 图像大小可以根据需要调整

# 隐藏轴线
ax.axis('off')

# 将DataFrame显示为表格
tbl = table(ax, top_rows, loc='center', colWidths=[0.15]*len(top_rows.columns))

# 设置表格样式
tbl.auto_set_font_size(False)
tbl.set_fontsize(10)
tbl.auto_set_column_width([i for i in range(len(top_rows.columns))])

# 保存图像为PNG文件
output_path = r'C:\Users\xwj\Desktop\data_mining\images\showcsv_table.png'
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# 关闭图形
plt.close()

print(f"表格图片已保存至: {output_path}")
