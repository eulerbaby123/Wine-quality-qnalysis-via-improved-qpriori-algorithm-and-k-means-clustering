import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 读取清洗后的数据
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\washed_winequality-white.csv'
df = pd.read_csv(file_path)

# 设置可视化的样式
sns.set(style="whitegrid")

# 创建一个图形对象，设置大小
plt.figure(figsize=(18, 10))

# 1. 绘制所有连续属性的曲线图
continuous_columns = df.columns[df.dtypes != 'object']  # 获取连续属性（非离散）
continuous_columns = continuous_columns[continuous_columns != 'quality']  # 排除质量属性

# 为每个连续属性绘制曲线图
for i, column in enumerate(continuous_columns, 1):
    plt.subplot(3, 4, i)  # 3行4列
    sns.kdeplot(df[column], shade=True, color='skyblue')
    plt.title(f'{column}的分布', fontsize=12)
    plt.xlabel(column, fontsize=10)
    plt.ylabel('密度', fontsize=10)

# 2. 绘制质量属性的条形图
plt.subplot(3, 4, len(continuous_columns) + 1)  # 放在曲线图之后
sns.countplot(data=df, x='quality', palette="Set2")
plt.title('质量分布', fontsize=12)
plt.xlabel('质量', fontsize=10)
plt.ylabel('数量', fontsize=10)

# 调整图像布局
plt.tight_layout()

# 保存到指定目录
save_path = r'C:\Users\xwj\Desktop\data_mining\images\attributes_and_quality_distribution.png'
plt.savefig(save_path, bbox_inches='tight')  # 保存图像并调整边距

# 显示图像
plt.show()

print(f"图像已保存到 {save_path} 。")
