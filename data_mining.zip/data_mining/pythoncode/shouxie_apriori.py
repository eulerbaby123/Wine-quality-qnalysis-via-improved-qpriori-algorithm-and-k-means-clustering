from collections import defaultdict
import pandas as pd

# 1. 加载数据集（从csv文件或直接用字符串作为输入）
def loadDataSet():
    data = [
        [1, 1, 1, 2, 1, 1, 1, 2, 2, 2, 2, 2],
        [2, 1, 1, 1, 1, 3, 3, 1, 1, 1, 2, 2],
        [3, 1, 1, 3, 1, 1, 2, 1, 1, 2, 2, 2]
    ]
    return data

# 2. 创建候选项集 C1
def createC1(dataSet):
    C1 = []
    for transaction in dataSet:
        for item in transaction:
            if [item] not in C1:
                C1.append([item])
    C1.sort()
    return list(map(frozenset, C1))

# 3. 扫描数据集，计算项集支持度
def scanD(D, CK, minSupport):
    ssCnt = defaultdict(int)
    for tid in D:
        for can in CK:
            if can.issubset(tid):
                ssCnt[can] += 1
    numItems = float(len(D))
    retList = []
    supportData = {}
    for key in ssCnt:
        support = ssCnt[key] / numItems
        if support >= minSupport:
            retList.append(key)
        supportData[key] = support
    return retList, supportData

# 4. 频繁项集两两组合
def aprioriGen(Lk, k):
    retList = []
    lenLk = len(Lk)
    for i in range(lenLk):
        for j in range(i + 1, lenLk):
            L1 = list(Lk[i])[:k - 2]
            L2 = list(Lk[j])[:k - 2]
            L1.sort()
            L2.sort()
            if L1 == L2:
                retList.append(Lk[i] | Lk[j])
    return retList

# 5. Apriori 主函数，生成频繁项集
def apriori(dataSet, minSupport=0.5):
    C1 = createC1(dataSet)
    D = list(map(set, dataSet))
    L1, supportData = scanD(D, C1, minSupport)
    L = [L1]
    k = 2
    while len(L[k - 2]) > 0:
        CK = aprioriGen(L[k - 2], k)
        Lk, supK = scanD(D, CK, minSupport)
        supportData.update(supK)
        L.append(Lk)
        k += 1
    return L, supportData

# 6. 计算关联规则
def generateRules(L, supportData, minConf=0.7):
    bigRuleList = []
    for i in range(1, len(L)):
        for freqSet in L[i]:
            H1 = [frozenset([item]) for item in freqSet]
            if i > 1:
                rulesFromConseq(freqSet, H1, supportData, bigRuleList, minConf)
            else:
                calcConf(freqSet, H1, supportData, bigRuleList, minConf)
    return bigRuleList

# 7. 计算置信度
def calcConf(freqSet, H, supportData, brl, minConf=0.7):
    prunedH = []
    for conseq in H:
        conf = supportData[freqSet] / supportData[freqSet - conseq]
        if conf >= minConf:
            print(f'{freqSet - conseq} ---> {conseq}, conf: {conf}')
            brl.append((freqSet - conseq, conseq, conf))
            prunedH.append(conseq)
    return prunedH

# 8. 根据结果递归生成更复杂的关联规则
def rulesFromConseq(freqSet, H, supportData, brl, minConf=0.7):
    m = len(H[0])
    if len(freqSet) > (m + 1):
        Hmp1 = aprioriGen(H, m + 1)
        Hmp1 = calcConf(freqSet, Hmp1, supportData, brl, minConf)
        if len(Hmp1) > 1:
            rulesFromConseq(freqSet, Hmp1, supportData, brl, minConf)

# 主程序入口
if __name__ == '__main__':
    # 加载数据集
    dataSet = loadDataSet()

    # 生成频繁项集
    minSupport = 0.5
    L, supportData = apriori(dataSet, minSupport)

    # 打印频繁项集
    print("频繁项集:")
    for level in L:
        print(level)

    # 生成关联规则
    minConf = 0.7
    rules = generateRules(L, supportData, minConf)

    # 打印关联规则
    print("\n关联规则:")
    for rule in rules:
        print(rule)
