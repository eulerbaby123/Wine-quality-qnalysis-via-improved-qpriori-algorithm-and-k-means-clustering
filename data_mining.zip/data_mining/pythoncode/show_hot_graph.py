import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 读取CSV文件，指定分隔符为分号
file_path = "C:/Users/xwj/Desktop/data_mining/csv/IQR_Z_cleaned.csv"
data = pd.read_csv(file_path, sep=';')

# 查看数据的前几行，确认数据结构
print(data.head())

# 创建热力图
plt.figure(figsize=(10, 8))  # 设置热力图大小
sns.heatmap(data.corr(), annot=True, cmap="coolwarm", fmt=".2f")  # 使用数据的相关系数矩阵来绘制热力图
plt.title("Correlation Heatmap")  # 添加标题
plt.show()
