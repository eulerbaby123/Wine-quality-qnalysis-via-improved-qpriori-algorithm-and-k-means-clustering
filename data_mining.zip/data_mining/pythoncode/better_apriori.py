import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
import time
# 1. 读取离散化后的数据
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\final_quality_clustered.csv'
data = pd.read_csv(file_path, delimiter=';')

# 2. 查看数据列名，确保我们选择的列存在
print(data.columns)

# 3. 修改为正确的列名，确保数据列在columns_to_convert中
# columns_to_convert = [  'density_cluster','volatile acidity_cluster','quality', 'residual sugar_cluster','citric acid_cluster']
#根据自己需要定义需要挖掘的关联属性
# columns_to_convert=['fixed acidity_cluster', 'volatile acidity_cluster', 'citric acid_cluster', 
#                       'residual sugar_cluster', 'chlorides_cluster', 'free sulfur dioxide_cluster', 
#                       'total sulfur dioxide_cluster', 'density_cluster', 'pH_cluster', 
#                       'sulphates_cluster', 'alcohol_cluster', 'quality']

# 4. 数据转换为布尔类型（适合Apriori）
data_bool = pd.get_dummies(data[columns_to_convert].astype(str), prefix_sep='_')

# 5. 动态调整支持度阈值
def adjust_support(data, min_support):
    if len(data) > 1000:
        return min_support * 1.3  # 数据较大时提高支持度
    elif len(data) < 100:
        return min_support * 0.6  # 数据较小时降低支持度
    return min_support

min_support = adjust_support(data, 0.05)  # 动态设置支持度阈值
# 计时开始
start_time = time.time()
# 6. 使用Apriori算法挖掘频繁项集
frequent_itemsets = apriori(data_bool, min_support=min_support, use_colnames=True)

# 7. 生成关联规则
min_confidence = 0.8
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=min_confidence, num_itemsets=len(frequent_itemsets))
# 计时结束
end_time = time.time()
elapsed_time = end_time - start_time
8. 筛选并展示结果
print("频繁项集：")
print(frequent_itemsets)

print("\n关联规则：")
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

# 9. 保存结果
frequent_itemsets.to_csv(r'C:\Users\xwj\Desktop\data_mining\csv\frequent_itemsets.csv', index=False, sep=';')
rules.to_csv(r'C:\Users\xwj\Desktop\data_mining\csv\association_rules.csv', index=False, sep=';')

print("\n结果已保存到以下文件：")
print("1. frequent_itemsets.csv - 频繁项集")
print("2. association_rules.csv - 关联规则")
print(f"\n挖掘耗时：{elapsed_time:.8f} 秒")