import pandas as pd

# 读取CSV文件
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\kmeans_discretized_auto.csv'
data = pd.read_csv(file_path, delimiter=';')

# 定义质量规则的映射函数
def quality_mapping(quality):
    if quality in [3, 4]:
        return 1  # 不合格酒质
    elif quality in [5]:
        return 2  # 合格品
    elif quality in [6]:
        return 3  # 合格品
    elif quality in [7,8, 9]:
        return 4  # 优等品
    else:
        return None  # 处理未知值

# 应用规则映射到quality列，并覆盖原有的quality列
data['quality'] = data['quality'].apply(quality_mapping)

# 检查是否有未处理的值
if data['quality'].isnull().any():
    print("Warning: 存在未映射的质量值，请检查quality列中的数据！")

# 保存新的CSV文件
output_path = r'C:\Users\xwj\Desktop\data_mining\csv\final_quality_clustered.csv'
data.to_csv(output_path, index=False, sep=';')

# 提示完成信息
print(f"聚类完成，新文件已保存到: {output_path}")
