import pandas as pd

# 加载数据集
file_path = r'C:\Users\xwj\Desktop\data_mining\csv\winequality-white.csv'
df = pd.read_csv(file_path, delimiter=';')

# 查看原始数据的前几行
print("原始数据：")
print(df.head())

# 原始数据的行数和列数
print(f"\n原始数据的形状：{df.shape}")
print(f"原始数据的总行数: {df.shape[0]}，列数: {df.shape[1]}")

# 删除含有缺失值的行
df_cleaned = df.dropna()

# 删除所有包含负数的行
df_cleaned = df_cleaned[(df_cleaned >= 0).all(axis=1)]

# 查看清洗后的数据
print("\n清洗后的数据：")
print(df_cleaned.head())

# 清洗后数据的形状
print(f"\n清洗后数据的形状：{df_cleaned.shape}")
print(f"清洗后数据的总行数: {df_cleaned.shape[0]}，列数: {df_cleaned.shape[1]}")

# 输出删除的行数
deleted_rows = df.shape[0] - df_cleaned.shape[0]
print(f"\n删除的行数: {deleted_rows}")

# 保存清洗后的数据到新的CSV文件
output_path = r'C:\Users\xwj\Desktop\data_mining\csv\washed_winequality-white.csv'
df_cleaned.to_csv(output_path, index=False)

print(f"清洗后的数据已保存至: {output_path}")
